/*
? [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/adc/adc1.h"
#include "mcc_generated_files/pwm_hs/pwm.h"
#include "mcc_generated_files/pwm_hs/pwm_hs_interface.h"

#include "mcc_generated_files/mcp802x/mcp802X_task.h"

/*
    Main application
*/

uint8_t sine_wave[] = {127,121,112,100,88,76,64,52,40,28,16,4,0,4,16,28,40,52,64,76,88,100,112,121};
uint8_t fault_flag = 0;

uint16_t Get_Duty(uint8_t duty)
{
    return (uint16_t)(PG1PER/100*duty);
}

uint8_t Get_Power(uint8_t power)
{
    return (uint8_t)(128*power/100);
}

void IO_RC3_CallBack(void)
{
    LATE = (LATE | 0x0400);
    //printf("Interrupt!!\r\n");
}

void MCP802X_FAULT_CallBack(void)
{
    fault_flag = 1;
}

void Sine_NoFeedBack()
{
    char cnt_a = 0;
    char cnt_b = 0;
    char cnt_c = 0;
    int ph_a, ph_b, ph_c;
    
    MCP802X_STATE mcp_state;
    
    while(1)
    {
        ph_a = Get_Duty(sine_wave[cnt_a]*100/128);
        ph_b = Get_Duty(sine_wave[cnt_b]*100/128);
        ph_c = Get_Duty(sine_wave[cnt_c]*100/128);
        
        //printf("ph %d\r\n", ph_a);
    
        PWM_DutyCycleSet(PWM_GENERATOR_1, ph_a);
        PWM_DutyCycleSet(PWM_GENERATOR_2, ph_b);
        PWM_DutyCycleSet(PWM_GENERATOR_3, ph_c);
        
        
        cnt_a++;
        cnt_a = cnt_a%24;
        cnt_b = (cnt_a + 8)%24;
        cnt_c = (cnt_a + 16)%24;

        
        LATE = (LATE & ~0x0400);
        DELAY_milliseconds(1);
        
        if(fault_flag == 1)
        {
            printf("error!\r\n");
            mcp_state = MCP802X_eHandleCommunication();
            MCP802X_SCHED_MODE s_mode = MCP802X_sGetMode();
            printf("MODE = %d : Fault = %d \r\n", (int)s_mode, (int)mcp_state);
            MCP802X_ENABLE_SetLow();
            DELAY_milliseconds(10);
            MCP802X_ENABLE_SetHigh();
            fault_flag = 0;
            
            //break;
        }
    }
    
    while(1);
    
    
}


int main(void)
{
    SYSTEM_Initialize();
    
    IO_RC3_SetInterruptHandler(IO_RC3_CallBack);
    MCP802X_FAULT_SetInterruptHandler(MCP802X_FAULT_CallBack);
    
    SCCP1_Timer_Start();
    PWM_Enable();


    char cmd = 0;
    //LATE = 0xffff;
    

    Sine_NoFeedBack();
    
    uint16_t dutyCycle;
    
    while(1)
    {
        printf("%d state\r\n", (PORTC & 0x0008) );
        LATE = 0x0000;
        DELAY_milliseconds(10);
    }
    
    while(1)
    {
//        LATE = 0x0400;
//        UART2_Write('a');
//        UART2_Write('\n');
//        DELAY_milliseconds(100);
      //LATE = 0x0000;
      
//        DELAY_milliseconds(100);
         // Add your application code ????
		//cmd = UART2_Read();
       //UART2_Write(cmd);
     // ADC1_SoftwareTriggerEnable();
      //ADC1_SoftwareTriggerEnable();
      //while(ADC1_IsConversionComplete == false){}
        dutyCycle++;
        if(dutyCycle >= 100){
            dutyCycle = 0;
        }
        dutyCycle = (dutyCycle%100);
        PWM_DutyCycleSet(PWM_GENERATOR_3, Get_Duty(dutyCycle));
//        PWM_SoftwareUpdateRequest(PWM_GENERATOR_4);

      int value = ADC1_ConversionResultGet(0);
      //printf("%d\n\r", value);
      DELAY_milliseconds(500);
      
      MCP802X_SCHED_MODE s_mode = MCP802X_sGetMode();
      MCP802X_STATE mcp_state = MCP802X_eHandleCommunication();
      
      printf("MODE = %d : Fault = %d \r\n", (int)s_mode, (int)mcp_state);
      
      printf("PER %d\r\n", Get_Duty(dutyCycle));
    }    
}


void UART2_RxCompleteCallback(void)
{ 
    //LATE = 0x0400;
    
} 